@extends('Website.EmployeeHome.profile')

@section('profile_info')
    <form method="POST" action="{{route('employee.cv.save')}}" enctype="multipart/form-data">
        <div style="display:flex;align-items: center;justify-content: center;margin-top: 100px">
            <input type="file" style="width:100px">
        </div>
    </form>
@endsection
