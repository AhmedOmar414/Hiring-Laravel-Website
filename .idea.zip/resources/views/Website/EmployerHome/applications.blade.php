@extends('Layouts.employerHomeLayoute')

@section('content')
    Welcome Applications
@endsection
