<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_general', function (Blueprint $table) {
            $table->foreignId('employee_id')->references('id')->on('users');
            $table->string('phone_number');
            $table->string('additional_phone');
            $table->string('gender');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_general', function (Blueprint $table) {
            //
        });
    }
};
