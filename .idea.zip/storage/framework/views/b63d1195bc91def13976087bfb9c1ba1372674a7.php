<?php $__env->startSection('content'); ?>
<div>
    <div class="row">
        <div class="col-md-4 " style="width: 25%;height:500px;margin-top: 20px">
            <div class="list-group" >
                <a href=<?php echo e(route('employee.general')); ?> type="button" class="list-group-item list-group-item-action <?php echo e(url()->current() == route('employee.general')?'active':''); ?>" style="height: 70px;padding-left: 20px;padding-top: 20px">General Info</a>
                <a href=<?php echo e(route('employee.career_interest')); ?>  type="button" class="list-group-item list-group-item-action <?php echo e(url()->current() == route('employee.career_interest')?'active':''); ?>" style="height: 70px;padding-left: 20px;padding-top: 20px" >Career Interest</a>
                <a href="<?php echo e(route('employee.education')); ?>" type="button" class="list-group-item list-group-item-action <?php echo e(url()->current() == route('employee.education')?'active':''); ?>" style="height: 70px;padding-left: 20px;padding-top: 20px">Education Info</a>
                <a href="<?php echo e(route('employee.experience')); ?>" type="button" class="list-group-item list-group-item-action <?php echo e(url()->current() == route('employee.experience')?'active':''); ?>" style="height: 70px;padding-left: 20px;padding-top: 20px">Experience Info</a>
                <a href="<?php echo e(route('employee.cv')); ?>" type="button" class="list-group-item list-group-item-action <?php echo e(url()->current() == route('employee.cv')?'active':''); ?>" style="height: 70px;padding-left: 20px;padding-top: 20px">Upload CV</a>
                <a href="<?php echo e(route('exit')); ?>" type="button" class="list-group-item list-group-item-action" style="height: 70px;padding-left: 20px;padding-top: 20px">Logout</a>
            </div>
        </div>
        <div class="col-md-8" style="margin-top: 20px;width: 65%">
            <?php echo $__env->yieldContent('profile_info'); ?>
            <?php echo $__env->yieldContent('scripts'); ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts._EmployeeHomeLayoute', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Website/EmployeeHome/profile.blade.php ENDPATH**/ ?>