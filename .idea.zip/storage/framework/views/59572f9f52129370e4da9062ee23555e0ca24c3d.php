<?php $__env->startSection('profile_info'); ?>
    <div style="display:flex;align-items: center;justify-content: center;margin-top: 100px">
        <input type="file" style="width:100px">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Website.EmployeeHome.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Website/EmployeeHome/uploadcv.blade.php ENDPATH**/ ?>