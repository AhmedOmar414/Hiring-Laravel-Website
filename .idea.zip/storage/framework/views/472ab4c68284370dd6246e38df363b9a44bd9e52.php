<!DOCTYPE html>
<html lang="zxx" class="no-js">


<?php echo $__env->make('Shared.Website._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>

<?php echo $__env->make('Shared.Website._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- start banner Area -->
<?php echo $__env->make('Shared.Website._banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End banner Area -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Start features Area -->
<?php echo $__env->make('Shared.Website._features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End features Area -->

<!-- Start popular-post Area -->
<?php echo $__env->make('Shared.Website._featurejobs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End popular-post Area -->

<!-- Start feature-categories Area -->
<?php echo $__env->make('Shared.Website._featurecategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End feature-categories Area -->

<!-- Start post Area -->
<?php echo $__env->make('Shared.Website._postarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End post Area -->


<!-- Start join us Area -->
<?php echo $__env->make('Shared.Website._joinus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End join us Area -->

<!-- start footer Area -->
<?php echo $__env->make('Shared.Website._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End footer Area -->


<?php echo $__env->make('Shared.Website._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>



<?php /**PATH F:\L3T2\Jobs Site\Implementation\Find-Jobs\resources\views/Layouts/_WebsiteLayoute.blade.php ENDPATH**/ ?>