<!DOCTYPE html>
<html lang="en">


<?php echo $__env->make('Shared.Dashboard._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body class="g-sidenav-show  bg-gray-200">

<?php echo $__env->make('Shared.Dashboard._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
<?php echo $__env->make('Shared.Dashboard._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('Shared.Dashboard._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>



<?php echo $__env->make('Shared.Dashboard._fixedplugin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('Shared.Dashboard._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH F:\L3T2\Jobs Site\Implementation\Find-Jobs\resources\views/Layouts/_DashboardLayoute.blade.php ENDPATH**/ ?>