<footer class="bg-dark" style="height:60px">
    <div class="container">
        <div style="padding-top:25px">
            <h5 style="text-align:center;color: white">Developed By Ahmed Omar (All Rights Reserved)</h5>
        </div>
    </div>
</footer>
<?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Shared/Website/_footer.blade.php ENDPATH**/ ?>