<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if(auth()->user()->is_employer == "0"): ?>
            <?php
            redirect('employee.skills')
            ?>
        <?php else: ?>
            <p>You are employer</p>
        <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Site\Implementation\Find-Jobs\resources\views/home.blade.php ENDPATH**/ ?>