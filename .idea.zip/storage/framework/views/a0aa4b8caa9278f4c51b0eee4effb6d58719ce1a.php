<section class="banner-area relative" id="home" style="height:75vh;margin-top: -100px">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row fullscreen d-flex align-items-center justify-content-center">
            <div class="banner-content col-lg-12">
                <h1 class="text-white">
                    <span>Find</span> Your Ideal Job
                </h1>
                <form action="#" class="serach-form-area">
                    <div class="row justify-content-center form-wrap">
                        <div class="col-lg-4 form-cols">
                            <select class="form-select" name="job_category" id="category_list"  aria-label="Default select example" style=" color: grey;border-color: darkgray" required>
                                <option selected disabled>select category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></div>
                        <div class="col-lg-3 form-cols">
                            <div class="default-select" id="default-selects"">
                            <select class="form-select" name="job_cat" id="sub_cat" aria-label="Default select example" style=" color: grey;border-color: darkgray" required>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-2 form-cols">
                        <button type="button" class="btn btn-info">
                            <span class="lnr lnr-magnifier"></span> Search
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $("#category_list").on('change',function(){
                let id = $(this).val();
                $('#sub_cat').empty();
                $.ajax({
                    method:'Get',
                    url:'/jobcat/'+id,
                    success: function(response) {
                        $.each(response.data,function(key,val){
                            $('#sub_cat').append("<option value='"+val.id+"'>"+val.job_name+"</option>");
                        });

                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            });
        });
    </script>
<?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Shared/Website/_banner.blade.php ENDPATH**/ ?>