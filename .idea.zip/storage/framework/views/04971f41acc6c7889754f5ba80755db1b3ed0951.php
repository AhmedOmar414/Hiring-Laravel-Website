<?php $__env->startSection('content'); ?>
    <div style="margin-top:40px">
        <div class="card shadow-sm p-3 mb-5 bg-white rounded " style="width: 100%;height:220px">
            <div class="row" style="margin-left:15px">
                <div class="card-title col-md-11">
                    <h4 style="color: #4a4ae3">Position Title</h4>
                    <div class="row" style="margin-left:0">
                        <div class="col-md-6" style="width: 90px;height: 25px;background-color:#d9d9d9;border-radius: 2px;text-align: center;padding-top: 3px">
                            <p style="font-size:13px"> career level</p>
                        </div>
                        <div class="col-md-6" style="width: 90px;height: 25px;background-color:#d9d9d9;border-radius: 2px;margin-left:5px;text-align: center;padding-top: 3px">
                            <p style="font-size:13px"> job type</p>
                        </div>
                    </div>
                    <p style="padding-top: 20px">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard<br> dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                </div>
                <div class="card-body col-md-1">
                    <img src=<?php echo e(url('Home/images/icon.png')); ?> width="50px">
                </div>
            </div>

            <a href="#" style="text-decoration: none;color: #4f4f4f" ><p style="margin-left:25px;"><img src=<?php echo e(url('Home/images/save.png')); ?> width="30px"> <span style="font-weight:bold">Save</span></p></a>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts._EmployeeHomeLayoute', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Website/EmployeeHome/EmployeeHome.blade.php ENDPATH**/ ?>