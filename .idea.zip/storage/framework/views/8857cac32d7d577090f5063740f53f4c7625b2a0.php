<?php $__env->startSection('content'); ?>

    <div class="container" style="width: 75%">
        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('offer.show',$offer->id)); ?>" style="text-decoration: none;color: black">
            <div class="card shadow-sm p-3 mb-5 bg-white rounded " style="width: 100%;height:270px;margin-top: 15px">
                <div class="row" style="margin-left:15px">
                    <div class="card-title col-md-11">
                        <h4 style="color: #4a4ae3"><?php echo e($offer->job_title); ?></h4>
                        <div class="row" style="margin-left:0;padding-top: 10px">
                            <div class="col-md-6" style="width: 90px;height: 25px;background-color:#d9d9d9;border-radius: 2px;text-align: center;padding-top: 3px">
                                <p style="font-size:13px"> <?php echo e($offer->career_level); ?></p>
                            </div>
                            <div class="col-md-6" style="width: 90px;height: 25px;background-color:#d9d9d9;border-radius: 2px;margin-left:5px;text-align: center;padding-top: 3px">
                                <p style="font-size:13px"> <?php echo e($offer->type); ?></p>
                            </div>
                        </div>
                        <p><br><?php echo e(\Illuminate\Support\Str::limit($offer->job_desc,250 )); ?></p>
                        <hr>
                        <p > Posted <?php echo e($offer->created_at->diffForHumans()); ?> </p>
                    </div>
                    <div class="card-body col-md-1" style="">

                        <img src="<?php echo e(asset('uploads/employer_images/'.\App\Models\EmployerGeneral::where('user_id',auth()->user()->id)->first()->image_url)); ?>" width="55px" height="40px" style="margin-left: -20px">
                    </div>
                </div>
            </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>


























<?php echo $__env->make('Layouts.employerHomeLayoute', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Website/EmployerHome/employerHome.blade.php ENDPATH**/ ?>