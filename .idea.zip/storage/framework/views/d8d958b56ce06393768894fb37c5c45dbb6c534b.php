<section class="callto-action-area section-gap" id="join">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="menu-content col-lg-9">
                <div class="title text-center">
                    <h1 class="mb-10 text-white">Join us today without any hesitation</h1>
                    <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                    <a class="primary-btn" href="#">I am a Candidate</a>
                    <a class="primary-btn" href="#">Request Free Demo</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH F:\L3T2\Jobs Site\Implementation\Find-Jobs\resources\views/Shared/Website/_joinus.blade.php ENDPATH**/ ?>