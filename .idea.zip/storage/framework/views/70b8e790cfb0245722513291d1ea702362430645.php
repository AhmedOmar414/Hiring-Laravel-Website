<?php $__env->startSection('profile_info'); ?>
    <form method="POST" action="<?php echo e(route('employee.career.update',$career->user_id)); ?>">
        <?php echo csrf_field(); ?>
        <?php if($errors->any): ?>
           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="inner">
                     <ul>
                           <li style="color: red"><?php echo e($error); ?></li>
                     </ul>
                 </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="card" style="width: 75%;">
            <div class="wrapper" style="width: 90%;margin-top: 30px">
                <input type="radio" name="career_level" id="option-1" value="student" required <?php echo e($career->career_level=='student'?'checked':''); ?>>
                <input type="radio" name="career_level" id="option-2" value="junior" required <?php echo e($career->career_level=='junior'?'checked':''); ?>>
                <input type="radio" name="career_level" id="option-3" value="senior" required <?php echo e($career->career_level=='senior'?'checked':''); ?>>
                <label for="option-1" class="option option-1">
                    <div class="dot"></div>
                    <span style="padding:0 15px 0 15px">Student</span>
                </label>
                <label for="option-2" class="option option-2">
                    <div class="dot"></div>
                    <span style="padding:0 15px 0 15px">Junior</span>
                </label>
                <label for="option-3" class="option option-3">
                    <div class="dot"></div>
                    <span style="padding:0 15px 0 15px">Senior</span>
                </label>
            </div>
            <div style="width: 90%;margin-top:10px;margin-left: 25px;margin-bottom: 40px;">
                <div>
                    <div class="row" style="padding-left: 13px;padding-top: 15px">
                        <input class="form-control" required name="skill1" type="text" value="<?php echo e($career->skill1); ?>" style="width: 105px;font-size:16px" >
                        <input class="form-control" required name="skill2" type="text" value="<?php echo e($career->skill2); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                        <input class="form-control" required name="skill3" type="text" value="<?php echo e($career->skill3); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                        <input class="form-control" required name="skill4" type="text" value="<?php echo e($career->skill4); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                    </div>
                    <div class="row" style="padding-left: 13px;padding-top: 15px">
                        <input class="form-control" required name="skill5" type="text" value="<?php echo e($career->skill5); ?>" style="width: 105px;font-size:16px" >
                        <input class="form-control" required name="skill6" type="text" value="<?php echo e($career->skill6); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                        <input class="form-control" required name="skill7" type="text" value="<?php echo e($career->skill7); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                        <input class="form-control" required name="skill8" type="text" value="<?php echo e($career->skill8); ?>" style="width: 105px;margin-left: 10px;font-size:16px">
                    </div>
                </div>
            </div>
            <div class="inner" style="margin-top: -40px">
                <div>
                    <input  class="form-control" name="job_title" value="<?php echo e($career->job_title); ?>" id="job_title" type="text" placeholder="job title" style="width:90%;height:50px" required>
                </div>
            </div>
            <div class="inner" style="margin-top: -20px;margin-left: 12px">
                <div class="row">
                    <input disabled class="form-control" name="category_name" value="<?php echo e($career->category->category_name); ?>" id="job_title" type="text" placeholder="job title" style="width:40%;height:50px" required>
                    <input  disabled class="form-control" name="job_name" value="<?php echo e($career->job->job_name); ?>" id="job_title" type="text" placeholder="job title" style="width:40%;height:50px;margin-left:25px" required>
                </div>
            </div>
            <div class="row" style="padding:1px 0 23px 20px">
                <div style="padding:15px 0 20px 25px; width:40%;" class="col-md-4">
                    <select class="form-select" name="category_id" id="category_list"  aria-label="Default select example" style=" color: grey;border-color: darkgray" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div style="padding:15px 0 20px 25px; width:40%" class="col-md-4">
                    <select class="form-select" name="job_id" id="sub_cat" aria-label="Default select example" style=" color: grey;border-color: darkgray" required>
                    </select>
                </div>
            </div>
            <div class="inner" style="margin-top: -40px;margin-bottom:20px">
                <div>
                    <input  class="form-control" name="expected_salary" value="<?php echo e($career->expected_salary); ?>" id="job_title" type="text" placeholder="accepted salary" style="width:90%;height:50px" required>
                </div>
            </div>
        </div>
        <div class="card" style="width:75%;margin-top:10px">
            <div>
                <button type="submit" class="btn btn-primary"  style="width:100%;padding-top:10px"> Update </button>
            </div>
        </div>
    </form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $("#category_list").on('change',function(){
                let id = $(this).val();
                $('#sub_cat').empty();
                $.ajax({
                    method:'Get',
                    url:'/jobcat/'+id,
                    success: function(response) {
                        $.each(response.data,function(key,val){
                            $('#sub_cat').append("<option value='"+val.id+"'>"+val.job_name+"</option>");
                        });

                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Website.EmployeeHome.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\L3T2\Jobs Project\Implementation\Find-Jobs\resources\views/Website/EmployeeHome/careerinterest.blade.php ENDPATH**/ ?>