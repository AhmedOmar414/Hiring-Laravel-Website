<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\EmployerGeneral;
use App\Models\JobOffers;
use App\Models\User;
use App\Traits\Media;
use Illuminate\Http\Request;

class EmployerHome extends Controller
{
    use Media;
    public function ReturnAddOfferPage(){
        $categories  = Category::all();
        return view('Website.EmployerHome.addoffer',compact('categories'));
    }
    public function ReturnEmployerHomePage(){
        $offers = JobOffers::where('user_id',auth()->user()->id)->get();
        return view('Website.EmployerHome.employerHome',compact(['offers']));
    }
    public function ReturnApplications(){
        return view('Website.EmployerHome.applications');
    }

    public function Profile(){
        $profile = EmployerGeneral::where('user_id',auth()->user()->id)->first();
        $user = User::find(auth()->user()->id);
        return view('Website.EmployerHome.profile',compact('profile','user'));
    }

    public function ProfileUpdate(Request $request){
        $data  = $request->all();
        $model = User::find(auth()->user()->id)->employer_general->first();

        $this->ProfileValidate($request);
        if ($request->image){
            $this->UpdateImage($model,$request);
        }
        $model->company_name = $data['company_name'];
        $model->company_location = $data['company_location'];
        $model->phone1 = $data['phone1'];
        $model->phone2 = $data['phone2'];
        $model->company_starting = $data['company_starting'];
        $model->save();
        notify()->success('Profile Updated Successfully');
        return redirect()->back();
    }

    public function UpdateImage($model,$request){
        $image = $model->image_url;
        unlink('uploads/employer_images/'.$image);
        $image_url = $this->StoreImage($request,'uploads/employer_images/');
        $model->image_url = $image_url;
    }
    public function ProfileValidate($request){
        $request->validate([
            'image'=> 'image|mimes:jpg,png|max:2048',

        ]);
    }

    public function SearchOffers(Request $request){

    }

    public function SaveOffer(Request $request){

        $data = $request->all();
        $offer = new JobOffers;

        $offer->career_level = $data['career_level'];
        $offer->job_title = $data['offer_name'];
        $offer->category_id = $data['category_name'];
        $offer->job_type = $data['jobs-type'];
        $offer->job_desc = $data['offer_desc'];
        $offer->skill1 = $data['skill1'];
        $offer->skill2 = $data['skill2'];
        $offer->skill3 = $data['skill3'];
        $offer->skill4 = $data['skill4'];
        $offer->skill5 = $data['skill5'];
        $offer->type = $data['type'];
        $offer->salary_range = $data['expected_salary'];
        $offer->user_id = auth()->user()->id;
        $offer->experience_years = $data['experience-years'];

        $offer->save();
        notify()->success('Offer Added Successfully');
        return redirect('Employer/home');
    }

    public function ShowOffer($id){

        $offers = JobOffers::find($id);
        $category = JobOffers::find($id)->category;
        return view('Website/EmployerHome/showoffer',compact(['offers','category']));
    }
}
