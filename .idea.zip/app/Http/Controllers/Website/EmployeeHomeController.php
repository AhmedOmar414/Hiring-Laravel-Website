<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\EmployeeCareer;
use App\Models\EmployeeEducation;
use App\Models\EmployeeGeneral;
use App\Models\User;
use App\Traits\Media;
use Illuminate\Http\Request;
use phpDocumentor\Reflection\Utils;

class EmployeeHomeController extends Controller
{
    use Media;
    public function Index(){
        return view('Website.EmployeeHome.EmployeeHome');
    }

    public function Profile(){
        return view('Website.EmployeeHome.profile');
    }
    public function GeneralInfo(){
        $employee = EmployeeGeneral::where('employee_id',auth()->user()->id)->first();
        $user = User::where('id',auth()->user()->id)->first();
        return view('Website.EmployeeHome.general_info',compact(['employee','user']));
    }
    public function UpdateGeneralInfo(Request $request,$id){
        $data = $request->all();
        $user = User::find($id);
        $general = EmployeeGeneral::where('employee_id',$id)->first();
        if($request->image){
            $image = $this->UpdateImage($general,$request);
            $data['image'] = $image;
        }
        $user->fill($data)->save();
        $general->fill($data)->save();
        return redirect()->back();
    }

    public function UpdateImage($model,$request){
        $image = $model->image_url;
        unlink('uploads/employee_images/'.$image);
        $image_url = $this->StoreImage($request,'uploads/employee_images/');
        $model->image_url = $image_url;
    }

    public function CareerInterest(){
        $categories = Category::all();
        $career = EmployeeCareer::where('user_id',auth()->user()->id)->with(['category','job'])->first();
        return view('Website.EmployeeHome.careerinterest',compact(['categories','career']));
    }

    public function UpdateCareerInterestInfo(Request $request,$id){
        $data = $request->all();
        $career = EmployeeCareer::where('user_id',$id)->first();

        $career->fill($data)->save();
        return redirect()->back();
    }

    public function Education(){
        $edu = EmployeeEducation::where('employee_id',auth()->user()->id)->first();
        return view('Website.EmployeeHome.education',compact('edu'));
    }

    public function UpdateEducationInfo(Request $request,$id){
        $data = $request->all();
        $edu = EmployeeEducation::where('employee_id',$id)->first();
        $edu->fill($data)->save();
        return redirect()->back();
    }

    public function Experience(){
        return view('Website.EmployeeHome.experience');
    }

    public function UploadCv(){
        return view('Website.EmployeeHome.uploadcv');
    }

    public function SaveCV(Request $request){
    }
}
