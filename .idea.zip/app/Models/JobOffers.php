<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class JobOffers extends Model
{
    use HasFactory;

    protected $table='job_offer';

    protected $fillable = [
      'career_level','jobs_type','category_id','job_id' ,'type','skill1','skill1','skill1','skill1','skill1','expected_salary','job_title','created_at',
    ];

    public function setTransactionDateAttribute($value)
    {
        $this->attributes['created_at'] = Carbon::createFromFormat('m/d/Y', $value)->format('Y-m-d');
    }

    public function category(){
        return $this->belongsTo(Category::class);
    }

}
